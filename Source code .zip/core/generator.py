import json
from typing import Dict, Any, Optional

def generate_singbox_config(
    node: Dict[str, Any],
    mode: str = "tun", # "tun" or "proxy"
    mixed_port: int = 2080,
    dns_server: str = "8.8.8.8"
) -> Dict[str, Any]:
    """
    Generates a production-ready sing-box 1.14 configuration dictionary.
    Supports both Outbound (VLESS, Reality, Trojan, SS, VMess)
    and Endpoint (WireGuard, AmneziaWG).
    """
    node_type = node.get("type", "outbound")
    node_config = dict(node["config"])
    node_tag = "proxy-out"
    node_config["tag"] = node_tag

    inbounds = [
        {
            "type": "mixed",
            "tag": "mixed-in",
            "listen": "127.0.0.1",
            "listen_port": mixed_port
        }
    ]

    if mode == "tun":
        inbounds.append({
            "type": "tun",
            "tag": "tun-in",
            "interface_name": "singbox-tun",
            "address": [
                "172.19.0.1/30"
            ],
            "auto_route": True,
            "strict_route": True,
            "stack": "mixed"
        })

    outbounds = [
        {
            "type": "direct",
            "tag": "direct"
        },
        {
            "type": "block",
            "tag": "block"
        }
    ]

    endpoints = []

    if node_type == "outbound":
        outbounds.insert(0, node_config)
        target_tag = node_tag
    else: # endpoint (WireGuard / AmneziaWG)
        endpoints.append(node_config)
        target_tag = node_tag

    # Modern Sing-box 1.14 DNS & Route Structure
    config = {
        "log": {
            "level": "info",
            "timestamp": True
        },
        "dns": {
            "servers": [
                {
                    "type": "udp",
                    "tag": "dns-remote",
                    "server": dns_server,
                    "detour": target_tag
                },
                {
                    "type": "local",
                    "tag": "dns-direct",
                    "detour": "direct"
                }
            ],
            "strategy": "prefer_ipv4"
        },
        "inbounds": inbounds,
        "outbounds": outbounds,
        "route": {
            "rules": [
                {
                    "protocol": "dns",
                    "action": "hijack-dns"
                },
                {
                    "ip_is_private": True,
                    "outbound": "direct"
                },
                {
                    "domain_suffix": [
                        ".ru",
                        "vk.com",
                        "yandex.ru",
                        "gosuslugi.ru",
                        "sberbank.ru",
                        "tbank.ru",
                        "kinopoisk.ru",
                        "mail.ru",
                        "ozon.ru",
                        "wildberries.ru",
                        "avito.ru"
                    ],
                    "outbound": "direct"
                },
                {
                    "inbound": ["mixed-in"] if mode == "proxy" else ["mixed-in", "tun-in"],
                    "outbound": target_tag
                }
            ],
            "auto_detect_interface": True,
            "default_domain_resolver": "dns-direct"
        }
    }

    if endpoints:
        config["endpoints"] = endpoints

    return config
