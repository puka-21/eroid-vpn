import base64
import json
import re
import urllib.parse
from typing import Dict, Any, List, Optional, Tuple
import requests
import yaml

def safe_b64decode(s: str) -> str:
    """Safe base64 decode handling missing padding and urlsafe characters."""
    s = s.strip()
    s = s.replace("-", "+").replace("_", "/")
    pad = len(s) % 4
    if pad:
        s += "=" * (4 - pad)
    try:
        return base64.b64decode(s).decode("utf-8", errors="replace")
    except Exception:
        return ""

def parse_vless(uri: str) -> Optional[Dict[str, Any]]:
    """
    Parse vless://<uuid>@<host>:<port>?<params>#<tag>
    """
    parsed = urllib.parse.urlparse(uri)
    if parsed.scheme.lower() != "vless":
        return None
    
    uuid = parsed.username or ""
    host = parsed.hostname or ""
    port = parsed.port or 443
    tag = urllib.parse.unquote(parsed.fragment) if parsed.fragment else f"VLESS-{host}:{port}"
    params = urllib.parse.parse_qs(parsed.query)
    
    def get_p(key: str, default: str = "") -> str:
        vals = params.get(key, [])
        return vals[0] if vals else default

    sec = get_p("security", "none").lower()
    net = get_p("type", "tcp").lower()
    flow = get_p("flow", "")
    sni = get_p("sni", "") or get_p("peer", "") or host
    fp = get_p("fp", "chrome")
    pbk = get_p("pbk", "")
    sid = get_p("sid", "")
    path = get_p("path", "/")
    service_name = get_p("serviceName", "")

    outbound: Dict[str, Any] = {
        "type": "vless",
        "tag": tag,
        "server": host,
        "server_port": port,
        "uuid": uuid
    }

    if flow:
        outbound["flow"] = flow

    if sec in ["tls", "reality"]:
        tls_config: Dict[str, Any] = {
            "enabled": True,
            "server_name": sni,
            "utls": {
                "enabled": True,
                "fingerprint": fp if fp else "chrome"
            }
        }
        if sec == "reality":
            tls_config["reality"] = {
                "enabled": True,
                "public_key": pbk,
                "short_id": sid
            }
        outbound["tls"] = tls_config

    if net == "ws":
        outbound["transport"] = {
            "type": "ws",
            "path": path,
            "headers": {
                "Host": sni
            }
        }
    elif net == "grpc":
        outbound["transport"] = {
            "type": "grpc",
            "service_name": service_name
        }
    elif net == "httpupgrade":
        outbound["transport"] = {
            "type": "httpupgrade",
            "path": path,
            "host": sni
        }

    return outbound

def parse_trojan(uri: str) -> Optional[Dict[str, Any]]:
    """
    Parse trojan://<password>@<host>:<port>?<params>#<tag>
    """
    parsed = urllib.parse.urlparse(uri)
    if parsed.scheme.lower() != "trojan":
        return None

    password = parsed.username or ""
    host = parsed.hostname or ""
    port = parsed.port or 443
    tag = urllib.parse.unquote(parsed.fragment) if parsed.fragment else f"Trojan-{host}:{port}"
    params = urllib.parse.parse_qs(parsed.query)

    def get_p(key: str, default: str = "") -> str:
        vals = params.get(key, [])
        return vals[0] if vals else default

    sni = get_p("sni", "") or host
    sec = get_p("security", "tls").lower()
    net = get_p("type", "tcp").lower()

    outbound: Dict[str, Any] = {
        "type": "trojan",
        "tag": tag,
        "server": host,
        "server_port": port,
        "password": password
    }

    if sec == "tls" or sec == "":
        outbound["tls"] = {
            "enabled": True,
            "server_name": sni
        }

    if net == "ws":
        outbound["transport"] = {
            "type": "ws",
            "path": get_p("path", "/"),
            "headers": {"Host": sni}
        }
    elif net == "grpc":
        outbound["transport"] = {
            "type": "grpc",
            "service_name": get_p("serviceName", "")
        }

    return outbound

def parse_shadowsocks(uri: str) -> Optional[Dict[str, Any]]:
    """
    Parse ss://<base64>#<tag> or ss://<method:pass>@<host:port>#<tag>
    """
    tag = ""
    raw = uri[5:]
    if "#" in raw:
        raw, tag_enc = raw.split("#", 1)
        tag = urllib.parse.unquote(tag_enc)

    if "@" in raw:
        user_info, host_port = raw.split("@", 1)
        decoded_info = safe_b64decode(user_info)
        if ":" in decoded_info:
            method, password = decoded_info.split(":", 1)
        elif ":" in user_info:
            method, password = user_info.split(":", 1)
        else:
            return None
        
        parsed_host = urllib.parse.urlparse(f"http://{host_port}")
        host = parsed_host.hostname or ""
        port = parsed_host.port or 8388
    else:
        decoded = safe_b64decode(raw)
        if "@" in decoded:
            user_info, host_port = decoded.split("@", 1)
            method, password = user_info.split(":", 1)
            parsed_host = urllib.parse.urlparse(f"http://{host_port}")
            host = parsed_host.hostname or ""
            port = parsed_host.port or 8388
        else:
            return None

    if not tag:
        tag = f"SS-{host}:{port}"

    return {
        "type": "shadowsocks",
        "tag": tag,
        "server": host,
        "server_port": port,
        "method": method,
        "password": password
    }

def parse_vmess(uri: str) -> Optional[Dict[str, Any]]:
    """
    Parse vmess://<base64_json>
    """
    raw = uri[8:]
    decoded = safe_b64decode(raw)
    if not decoded:
        return None
    try:
        data = json.loads(decoded)
        host = data.get("add", "")
        port = int(data.get("port", 443))
        uuid = data.get("id", "")
        tag = data.get("ps", f"VMess-{host}:{port}")
        net = data.get("net", "tcp")
        tls = data.get("tls", "")
        sni = data.get("sni", "") or host
        path = data.get("path", "/")

        outbound: Dict[str, Any] = {
            "type": "vmess",
            "tag": tag,
            "server": host,
            "server_port": port,
            "uuid": uuid,
            "alter_id": int(data.get("aid", 0)),
            "security": "auto"
        }

        if tls == "tls":
            outbound["tls"] = {
                "enabled": True,
                "server_name": sni
            }

        if net == "ws":
            outbound["transport"] = {
                "type": "ws",
                "path": path,
                "headers": {"Host": sni}
            }
        elif net == "grpc":
            outbound["transport"] = {
                "type": "grpc",
                "service_name": path
            }

        return outbound
    except Exception:
        return None

def parse_wireguard_or_awg(uri: str) -> Optional[Dict[str, Any]]:
    """
    Parse wireguard:// or awg:// link into sing-box endpoint structure.
    """
    parsed = urllib.parse.urlparse(uri)
    scheme = parsed.scheme.lower()
    if scheme not in ["wireguard", "awg", "wg"]:
        return None

    private_key = parsed.username or ""
    host = parsed.hostname or ""
    port = parsed.port or 51820
    tag = urllib.parse.unquote(parsed.fragment) if parsed.fragment else f"WireGuard-{host}:{port}"
    params = urllib.parse.parse_qs(parsed.query)

    def get_p(key: str, default: str = "") -> str:
        vals = params.get(key, [])
        return vals[0] if vals else default

    public_key = get_p("publickey") or get_p("peer_public_key") or get_p("pubkey")
    preshared_key = get_p("presharedkey") or get_p("psk")
    local_address = get_p("address") or get_p("ip") or "10.0.0.2/32"
    mtu = int(get_p("mtu") or 1420)

    # AmneziaWG obfuscation parameters
    jc = get_p("jc")
    jmin = get_p("jmin")
    jmax = get_p("jmax")
    s1 = get_p("s1")
    s2 = get_p("s2")
    h1 = get_p("h1")
    h2 = get_p("h2")
    h3 = get_p("h3")
    h4 = get_p("h4")

    addresses = [a.strip() for a in local_address.split(",") if a.strip()]

    endpoint: Dict[str, Any] = {
        "type": "wireguard",
        "tag": tag,
        "system": False,
        "address": addresses,
        "private_key": private_key,
        "mtu": mtu,
        "peers": [
            {
                "address": host,
                "port": port,
                "public_key": public_key,
                "allowed_ips": ["0.0.0.0/0", "::/0"]
            }
        ]
    }

    if preshared_key:
        endpoint["peers"][0]["pre_shared_key"] = preshared_key

    # If Amnezia parameters are given, preserve them in custom fields or reserved
    if jc:
        endpoint["junk_packet_count"] = int(jc)
    if jmin:
        endpoint["junk_packet_min_size"] = int(jmin)
    if jmax:
        endpoint["junk_packet_max_size"] = int(jmax)
    if s1 and s2:
        endpoint["init_packet_junk_size"] = int(s1)
        endpoint["response_packet_junk_size"] = int(s2)

    return endpoint

def parse_link(line: str) -> Optional[Tuple[str, Dict[str, Any]]]:
    """
    Parse any single link line.
    Returns ("outbound", config_dict) or ("endpoint", config_dict).
    """
    line = line.strip()
    if not line:
        return None

    if line.startswith("vless://"):
        item = parse_vless(line)
        return ("outbound", item) if item else None
    elif line.startswith("trojan://"):
        item = parse_trojan(line)
        return ("outbound", item) if item else None
    elif line.startswith("ss://"):
        item = parse_shadowsocks(line)
        return ("outbound", item) if item else None
    elif line.startswith("vmess://"):
        item = parse_vmess(line)
        return ("outbound", item) if item else None
    elif line.startswith("wireguard://") or line.startswith("awg://") or line.startswith("wg://"):
        item = parse_wireguard_or_awg(line)
        return ("endpoint", item) if item else None
    return None

def parse_clash_yaml(content: str) -> List[Tuple[str, Dict[str, Any]]]:
    """
    Parse proxies from Clash / Mihomo YAML subscriptions.
    """
    results: List[Tuple[str, Dict[str, Any]]] = []
    try:
        data = yaml.safe_load(content)
        if not isinstance(data, dict):
            return results
        proxies = data.get("proxies", [])
        for p in proxies:
            p_type = p.get("type", "").lower()
            name = p.get("name", "Proxy")
            server = p.get("server", "")
            port = int(p.get("port", 443))

            if p_type == "vless":
                outbound = {
                    "type": "vless",
                    "tag": name,
                    "server": server,
                    "server_port": port,
                    "uuid": p.get("uuid", "")
                }
                if p.get("flow"):
                    outbound["flow"] = p["flow"]
                reality = p.get("reality-opts", {})
                tls = p.get("tls", False)
                if tls or reality:
                    tls_conf = {
                        "enabled": True,
                        "server_name": p.get("servername", server),
                        "utls": {
                            "enabled": True,
                            "fingerprint": p.get("client-fingerprint", "chrome")
                        }
                    }
                    if reality:
                        tls_conf["reality"] = {
                            "enabled": True,
                            "public_key": reality.get("public-key", ""),
                            "short_id": reality.get("short-id", "")
                        }
                    outbound["tls"] = tls_conf
                results.append(("outbound", outbound))

            elif p_type == "trojan":
                outbound = {
                    "type": "trojan",
                    "tag": name,
                    "server": server,
                    "server_port": port,
                    "password": str(p.get("password", "")),
                    "tls": {
                        "enabled": True,
                        "server_name": p.get("sni", server)
                    }
                }
                results.append(("outbound", outbound))

            elif p_type == "ss":
                outbound = {
                    "type": "shadowsocks",
                    "tag": name,
                    "server": server,
                    "server_port": port,
                    "method": p.get("cipher", ""),
                    "password": str(p.get("password", ""))
                }
                results.append(("outbound", outbound))

            elif p_type == "wireguard":
                endpoint = {
                    "type": "wireguard",
                    "tag": name,
                    "system": False,
                    "address": [p.get("ip", "10.0.0.2/32")],
                    "private_key": p.get("private-key", ""),
                    "peers": [
                        {
                            "address": server,
                            "port": port,
                            "public_key": p.get("public-key", ""),
                            "allowed_ips": ["0.0.0.0/0", "::/0"]
                        }
                    ]
                }
                results.append(("endpoint", endpoint))
    except Exception:
        pass
    return results

def fetch_and_parse_subscription(sub_text_or_url: str) -> Tuple[List[Dict[str, Any]], Dict[str, str]]:
    """
    Fetches (if URL) and parses any subscription format:
    Returns (nodes_list, metadata_dict).
    Each node has {
        "id": int,
        "name": str,
        "type": "outbound" | "endpoint",
        "protocol": "VLESS" | "Reality" | "Trojan" | "Shadowsocks" | "WireGuard" | "VMess" | "AmneziaWG",
        "config": dict,
        "address": str,
        "port": int
    }
    """
    raw_content = sub_text_or_url.strip()
    meta: Dict[str, str] = {}

    if raw_content.startswith("http://") or raw_content.startswith("https://"):
        headers = {
            "User-Agent": "v2rayN/6.23 sing-box/1.14.4 ClashMeta/1.18.0"
        }
        resp = requests.get(raw_content, headers=headers, timeout=15)
        raw_content = resp.text
        if "subscription-userinfo" in resp.headers:
            meta["userinfo"] = resp.headers["subscription-userinfo"]
        if "profile-title" in resp.headers:
            meta["title"] = urllib.parse.unquote(resp.headers["profile-title"])

    # 1. Check if raw JSON (sing-box configuration)
    try:
        json_obj = json.loads(raw_content)
        nodes: List[Dict[str, Any]] = []
        if isinstance(json_obj, dict):
            for out in json_obj.get("outbounds", []):
                t = out.get("type")
                if t in ["vless", "trojan", "shadowsocks", "vmess"]:
                    proto = t.upper()
                    if t == "vless" and out.get("tls", {}).get("reality"):
                        proto = "VLESS-Reality"
                    nodes.append({
                        "name": out.get("tag", f"{proto}-{out.get('server')}"),
                        "type": "outbound",
                        "protocol": proto,
                        "config": out,
                        "address": out.get("server", ""),
                        "port": out.get("server_port", 443)
                    })
            for ep in json_obj.get("endpoints", []):
                if ep.get("type") == "wireguard":
                    peer = ep.get("peers", [{}])[0]
                    nodes.append({
                        "name": ep.get("tag", f"WireGuard-{peer.get('address')}"),
                        "type": "endpoint",
                        "protocol": "WireGuard",
                        "config": ep,
                        "address": peer.get("address", ""),
                        "port": peer.get("port", 51820)
                    })
            if nodes:
                return nodes, meta
    except Exception:
        pass

    # 2. Check if Clash YAML
    if "proxies:" in raw_content:
        clash_items = parse_clash_yaml(raw_content)
        if clash_items:
            nodes = []
            for item_type, conf in clash_items:
                proto = conf.get("type", "").upper()
                if item_type == "outbound":
                    addr = conf.get("server", "")
                    port = conf.get("server_port", 443)
                    if proto == "VLESS" and conf.get("tls", {}).get("reality"):
                        proto = "VLESS-Reality"
                else:
                    peer = conf.get("peers", [{}])[0]
                    addr = peer.get("address", "")
                    port = peer.get("port", 51820)
                nodes.append({
                    "name": conf.get("tag", f"{proto}-{addr}"),
                    "type": item_type,
                    "protocol": proto,
                    "config": conf,
                    "address": addr,
                    "port": port
                })
            return nodes, meta

    # 3. Check Base64 lines or plain URI lines
    decoded_body = safe_b64decode(raw_content)
    text_to_parse = decoded_body if (decoded_body and ("vless://" in decoded_body or "trojan://" in decoded_body or "ss://" in decoded_body or "vmess://" in decoded_body or "wireguard://" in decoded_body or "awg://" in decoded_body)) else raw_content

    lines = [line.strip() for line in text_to_parse.splitlines() if line.strip()]
    parsed_items: List[Dict[str, Any]] = []

    for line in lines:
        res = parse_link(line)
        if res:
            item_type, conf = res
            proto = conf.get("type", "").upper()
            if item_type == "outbound":
                addr = conf.get("server", "")
                port = conf.get("server_port", 443)
                if proto == "VLESS" and conf.get("tls", {}).get("reality"):
                    proto = "VLESS-Reality"
            else:
                peer = conf.get("peers", [{}])[0]
                addr = peer.get("address", "")
                port = peer.get("port", 51820)
                if "junk_packet_count" in conf or line.startswith("awg://"):
                    proto = "AmneziaWG"
                else:
                    proto = "WireGuard"

            parsed_items.append({
                "name": conf.get("tag", f"{proto}-{addr}"),
                "type": item_type,
                "protocol": proto,
                "config": conf,
                "address": addr,
                "port": port
            })

    return parsed_items, meta
