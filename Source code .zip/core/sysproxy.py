import winreg
import ctypes
from typing import Optional

INTERNET_OPTION_SETTINGS_CHANGED = 39
INTERNET_OPTION_REFRESH = 37

def refresh_system_proxy():
    """Notify system/browsers that internet settings have changed."""
    try:
        wininet = ctypes.windll.wininet
        wininet.InternetSetOptionW(0, INTERNET_OPTION_SETTINGS_CHANGED, 0, 0)
        wininet.InternetSetOptionW(0, INTERNET_OPTION_REFRESH, 0, 0)
    except Exception:
        pass

def enable_system_proxy(host: str = "127.0.0.1", port: int = 2080):
    """Enable Windows system HTTP/SOCKS proxy."""
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
            0,
            winreg.KEY_SET_VALUE
        )
        proxy_str = f"http={host}:{port};https={host}:{port};socks={host}:{port}"
        bypass_str = "localhost;127.*;10.*;172.16.*;192.168.*;*.local;<local>"

        winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(key, "ProxyServer", 0, winreg.REG_SZ, proxy_str)
        winreg.SetValueEx(key, "ProxyOverride", 0, winreg.REG_SZ, bypass_str)
        winreg.CloseKey(key)

        refresh_system_proxy()
        return True
    except Exception as e:
        print(f"Error enabling proxy: {e}")
        return False

def disable_system_proxy():
    """Disable Windows system proxy."""
    try:
        key = winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Internet Settings",
            0,
            winreg.KEY_SET_VALUE
        )
        winreg.SetValueEx(key, "ProxyEnable", 0, winreg.REG_DWORD, 0)
        winreg.CloseKey(key)

        refresh_system_proxy()
        return True
    except Exception as e:
        print(f"Error disabling proxy: {e}")
        return False
