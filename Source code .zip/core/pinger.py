import socket
import time
from concurrent.futures import ThreadPoolExecutor
from typing import Dict, Any, List, Callable, Optional

def test_node_latency(address: str, port: int, timeout: float = 2.0) -> int:
    """
    Measures TCP handshake latency to the server in milliseconds.
    Returns latency in ms or -1 if timeout/error.
    """
    if not address or port <= 0:
        return -1

    start_time = time.perf_counter()
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        sock.connect((address, port))
        elapsed = (time.perf_counter() - start_time) * 1000
        sock.close()
        return max(1, int(elapsed))
    except Exception:
        return -1

def test_all_nodes(
    nodes: List[Dict[str, Any]],
    callback: Optional[Callable[[int, int], None]] = None,
    max_workers: int = 15
) -> Dict[int, int]:
    """
    Tests latency for all nodes concurrently.
    callback(node_index, latency_ms) is invoked as each test completes.
    """
    results: Dict[int, int] = {}

    def _worker(idx: int, node: Dict[str, Any]):
        addr = node.get("address", "")
        port = node.get("port", 443)
        lat = test_node_latency(addr, port)
        results[idx] = lat
        if callback:
            callback(idx, lat)
        return idx, lat

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(_worker, i, n) for i, n in enumerate(nodes)]
        for f in futures:
            try:
                f.result()
            except Exception:
                pass

    return results
