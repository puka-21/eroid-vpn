import os
import sys
import subprocess
import threading
import json
import ctypes
from pathlib import Path
from typing import Callable, Optional, Dict, Any
from core.sysproxy import enable_system_proxy, disable_system_proxy

def is_admin() -> bool:
    """Check if the current process has Windows Administrator rights."""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin() != 0
    except Exception:
        return False

class SingBoxRunner:
    def __init__(self, base_dir: Optional[str] = None):
        if base_dir is None:
            self.base_dir = Path(__file__).resolve().parent.parent
        else:
            self.base_dir = Path(base_dir)

        self.bin_path = self.base_dir / "bin" / "sing-box.exe"
        self.config_path = self.base_dir / "runtime_config.json"
        self.process: Optional[subprocess.Popen] = None
        self.log_callback: Optional[Callable[[str], None]] = None
        self.status_callback: Optional[Callable[[str], None]] = None
        self.current_mode = "tun"
        self.lock = threading.Lock()

    def set_callbacks(
        self,
        log_cb: Optional[Callable[[str], None]] = None,
        status_cb: Optional[Callable[[str], None]] = None
    ):
        self.log_callback = log_cb
        self.status_callback = status_cb

    def is_running(self) -> bool:
        with self.lock:
            if self.process is None:
                return False
            poll = self.process.poll()
            return poll is None

    def start(self, config_dict: Dict[str, Any], mode: str = "tun") -> bool:
        if self.is_running():
            self.stop()

        self.current_mode = mode

        # Write runtime configuration
        try:
            with open(self.config_path, "w", encoding="utf-8") as f:
                json.dump(config_dict, f, indent=2, ensure_ascii=False)
        except Exception as e:
            if self.log_callback:
                self.log_callback(f"[ERROR] Failed to save config: {e}")
            return False

        if not self.bin_path.exists():
            if self.log_callback:
                self.log_callback(f"[ERROR] sing-box.exe not found at {self.bin_path}")
            return False

        # Hide console window on Windows
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0

        cmd = [
            str(self.bin_path),
            "run",
            "-c", str(self.config_path),
            "-D", str(self.base_dir / "bin")
        ]

        try:
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                encoding="utf-8",
                errors="replace",
                startupinfo=startupinfo,
                creationflags=subprocess.CREATE_NO_WINDOW
            )
        except Exception as e:
            if self.log_callback:
                self.log_callback(f"[ERROR] Failed to launch sing-box: {e}")
            return False

        # Start background reader thread for logs
        reader_thread = threading.Thread(target=self._log_reader, daemon=True)
        reader_thread.start()

        # If system proxy mode is selected, enable Windows system proxy
        if mode == "proxy":
            enable_system_proxy("127.0.0.1", 2080)

        if self.status_callback:
            self.status_callback("connected")

        if self.log_callback:
            self.log_callback(f"[INFO] sing-box started in {mode.upper()} mode")

        return True

    def _log_reader(self):
        proc = self.process
        if not proc or not proc.stdout:
            return

        for line in iter(proc.stdout.readline, ""):
            clean_line = line.strip()
            if clean_line and self.log_callback:
                self.log_callback(clean_line)

        proc.stdout.close()
        proc.wait()

        with self.lock:
            if self.process == proc:
                self.process = None

        if self.current_mode == "proxy":
            disable_system_proxy()

        if self.status_callback:
            self.status_callback("disconnected")

        if self.log_callback:
            self.log_callback("[INFO] sing-box process stopped")

    def stop(self):
        with self.lock:
            proc = self.process
            self.process = None

        if proc and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=2)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

        if self.current_mode == "proxy":
            disable_system_proxy()

        if self.status_callback:
            self.status_callback("disconnected")

        if self.log_callback:
            self.log_callback("[INFO] VPN disconnected")
