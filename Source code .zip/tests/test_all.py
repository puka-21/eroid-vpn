import unittest
import os
import sys
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

from core.parser import (
    parse_vless, parse_trojan, parse_shadowsocks,
    parse_wireguard_or_awg, parse_clash_yaml,
    fetch_and_parse_subscription, safe_b64decode
)
from core.generator import generate_singbox_config

class TestVpnClient(unittest.TestCase):
    def test_vless_reality_parsing(self):
        url = (
            "vless://96238b69-8254-47b8-bc23-c90ad7a17726@198.51.100.1:443"
            "?type=tcp&security=reality&pbk=x09l6bZ2h3eWd5jklmnopqrs_tuv-wxyz0123456789"
            "&fp=chrome&sni=yahoo.com&sid=abcdef0123456789&flow=xtls-rprx-vision#My-Reality-Server"
        )
        res = parse_vless(url)
        self.assertIsNotNone(res)
        self.assertEqual(res["type"], "vless")
        self.assertEqual(res["server"], "198.51.100.1")
        self.assertEqual(res["server_port"], 443)
        self.assertEqual(res["tag"], "My-Reality-Server")
        self.assertEqual(res["flow"], "xtls-rprx-vision")
        self.assertTrue(res["tls"]["enabled"])
        self.assertEqual(res["tls"]["reality"]["public_key"], "x09l6bZ2h3eWd5jklmnopqrs_tuv-wxyz0123456789")

    def test_trojan_parsing(self):
        url = "trojan://mypassword123@198.51.100.2:443?security=tls&sni=myhost.com#Trojan-Node"
        res = parse_trojan(url)
        self.assertIsNotNone(res)
        self.assertEqual(res["type"], "trojan")
        self.assertEqual(res["password"], "mypassword123")
        self.assertEqual(res["server"], "198.51.100.2")
        self.assertEqual(res["tls"]["server_name"], "myhost.com")

    def test_wireguard_and_amnezia_parsing(self):
        # AmneziaWG format
        awg_url = (
            "awg://aW5wdXRfcHJpdmF0ZV9rZXk=@198.51.100.3:51820"
            "?publickey=b3V0cHV0X3B1YmxpY19rZXk=&address=10.0.0.2/32"
            "&jc=4&jmin=40&jmax=70&s1=15&s2=25#AWG-Node"
        )
        res = parse_wireguard_or_awg(awg_url)
        self.assertIsNotNone(res)
        self.assertEqual(res["type"], "wireguard")
        self.assertEqual(res["tag"], "AWG-Node")
        self.assertEqual(res["peers"][0]["address"], "198.51.100.3")
        self.assertEqual(res["peers"][0]["port"], 51820)
        self.assertEqual(res["junk_packet_count"], 4)

    def test_config_generation(self):
        url = (
            "vless://96238b69-8254-47b8-bc23-c90ad7a17726@198.51.100.1:443"
            "?type=tcp&security=reality&pbk=x09l6bZ2h3eWd5jklmnopqrs_tuv-wxyz0123456789"
            "&fp=chrome&sni=yahoo.com&sid=abcdef0123456789&flow=xtls-rprx-vision#Node1"
        )
        node_cfg = parse_vless(url)
        node = {"type": "outbound", "config": node_cfg, "name": "Node1"}
        
        # Test TUN mode config
        cfg_tun = generate_singbox_config(node, mode="tun")
        self.assertEqual(len(cfg_tun["inbounds"]), 2)
        self.assertEqual(cfg_tun["inbounds"][1]["type"], "tun")
        self.assertEqual(cfg_tun["dns"]["servers"][0]["server"], "8.8.8.8")

        # Test Proxy mode config
        cfg_proxy = generate_singbox_config(node, mode="proxy")
        self.assertEqual(len(cfg_proxy["inbounds"]), 1)
        self.assertEqual(cfg_proxy["inbounds"][0]["type"], "mixed")

if __name__ == "__main__":
    unittest.main()
