import sys
import os
import json
import ctypes
import threading
from pathlib import Path
from typing import List, Dict, Any, Optional

from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel,
    QPushButton, QLineEdit, QRadioButton, QButtonGroup, QTableWidget,
    QTableWidgetItem, QHeaderView, QTextEdit, QTabWidget, QFrame,
    QMessageBox, QSystemTrayIcon, QMenu, QAbstractItemView, QProgressBar
)
from PyQt6.QtCore import Qt, pyqtSignal, QObject, QTimer
from PyQt6.QtGui import QIcon, QColor, QFont

from core.parser import fetch_and_parse_subscription, parse_link
from core.generator import generate_singbox_config
from core.runner import SingBoxRunner, is_admin
from core.pinger import test_all_nodes, test_node_latency
from ui.styles import MODERN_STYLE

class SignalBridge(QObject):
    log_received = pyqtSignal(str)
    status_changed = pyqtSignal(str)
    ping_updated = pyqtSignal(int, int) # index, latency_ms
    subscription_loaded = pyqtSignal(list, dict)

class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sing-Box VPN Client")
        self.setMinimumSize(880, 680)
        self.resize(940, 720)

        self.base_dir = Path(__file__).resolve().parent.parent
        self.settings_file = self.base_dir / "settings.json"
        
        self.nodes: List[Dict[str, Any]] = []
        self.selected_node_idx = -1
        self.is_connected = False
        self.active_mode = "tun"

        self.bridge = SignalBridge()
        self.bridge.log_received.connect(self.append_log)
        self.bridge.status_changed.connect(self.on_runner_status)
        self.bridge.ping_updated.connect(self.on_ping_result)
        self.bridge.subscription_loaded.connect(self.on_sub_loaded)

        self.runner = SingBoxRunner(str(self.base_dir))
        self.runner.set_callbacks(
            log_cb=lambda msg: self.bridge.log_received.emit(msg),
            status_cb=lambda st: self.bridge.status_changed.emit(st)
        )

        self.init_ui()
        self.load_settings()

    def init_ui(self):
        self.setStyleSheet(MODERN_STYLE)

        central = QWidget()
        self.setCentralWidget(central)
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(18, 18, 18, 18)
        main_layout.setSpacing(14)

        # 1. Header Card
        header_card = QFrame()
        header_card.setProperty("class", "header-card")
        header_layout = QHBoxLayout(header_card)
        header_layout.setContentsMargins(16, 12, 16, 12)

        # Status & Title
        title_box = QVBoxLayout()
        title_box.setSpacing(4)
        
        title_lbl = QLabel("SING-BOX VPN CLIENT")
        title_lbl.setFont(QFont("Segoe UI", 16, QFont.Weight.Bold))
        title_lbl.setStyleSheet("color: #ffffff; letter-spacing: 1px;")

        self.status_lbl = QLabel("●  Отключено")
        self.status_lbl.setFont(QFont("Segoe UI", 12, QFont.Weight.DemiBold))
        self.status_lbl.setStyleSheet("color: #94a3b8;")

        title_box.addWidget(title_lbl)
        title_box.addWidget(self.status_lbl)
        header_layout.addLayout(title_box)

        header_layout.addStretch()

        # Admin Badge & Restart button if not admin
        admin_box = QVBoxLayout()
        admin_box.setAlignment(Qt.AlignmentFlag.AlignRight)
        if is_admin():
            self.admin_lbl = QLabel("🛡️ Запущен с правами Администратора (TUN активен)")
            self.admin_lbl.setStyleSheet("color: #10b981; font-weight: 600; font-size: 11px;")
            admin_box.addWidget(self.admin_lbl)
        else:
            self.admin_lbl = QLabel("⚠️ Запущен без прав Администратора")
            self.admin_lbl.setStyleSheet("color: #f59e0b; font-weight: 600; font-size: 11px;")
            elevate_btn = QPushButton("Перезапустить от Администратора")
            elevate_btn.setStyleSheet("""
                QPushButton {
                    background: #d97706; color: white; border: none; border-radius: 4px; padding: 4px 8px; font-size: 11px;
                }
                QPushButton:hover { background: #b45309; }
            """)
            elevate_btn.clicked.connect(self.restart_as_admin)
            admin_box.addWidget(self.admin_lbl)
            admin_box.addWidget(elevate_btn)
        header_layout.addLayout(admin_box)

        # Big Connect Button
        self.connect_btn = QPushButton("ПОДКЛЮЧИТЬ")
        self.connect_btn.setObjectName("connectBtn")
        self.connect_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.connect_btn.clicked.connect(self.toggle_connection)
        header_layout.addWidget(self.connect_btn)

        main_layout.addWidget(header_card)

        # 2. Mode Selector Bar
        mode_card = QFrame()
        mode_card.setProperty("class", "card")
        mode_layout = QHBoxLayout(mode_card)
        mode_layout.setContentsMargins(14, 10, 14, 10)

        mode_lbl = QLabel("Режим работы:")
        mode_lbl.setStyleSheet("font-weight: 700; color: #94a3b8;")
        mode_layout.addWidget(mode_lbl)

        self.btn_group_mode = QButtonGroup(self)
        self.radio_tun = QRadioButton("TUN Mode (Глобальный VPN для всех игр и приложений)")
        self.radio_proxy = QRadioButton("System Proxy (Только браузеры и системный прокси)")
        
        self.radio_tun.setChecked(True)
        self.btn_group_mode.addButton(self.radio_tun)
        self.btn_group_mode.addButton(self.radio_proxy)

        self.radio_tun.toggled.connect(self.on_mode_changed)

        mode_layout.addWidget(self.radio_tun)
        mode_layout.addWidget(self.radio_proxy)
        mode_layout.addStretch()

        main_layout.addWidget(mode_card)

        # 3. Main Tabs (Servers, Logs, Settings)
        self.tabs = QTabWidget()

        # Tab 1: Servers
        servers_tab = QWidget()
        servers_layout = QVBoxLayout(servers_tab)
        servers_layout.setContentsMargins(12, 12, 12, 12)
        servers_layout.setSpacing(10)

        # Subscription Bar
        sub_layout = QHBoxLayout()
        sub_layout.setSpacing(8)

        self.sub_input = QLineEdit()
        self.sub_input.setPlaceholderText("Вставьте ссылку на подписку (URL) или конфигурацию...")
        sub_layout.addWidget(self.sub_input, stretch=1)

        self.btn_load_sub = QPushButton("Обновить подписку")
        self.btn_load_sub.setProperty("class", "action-btn")
        self.btn_load_sub.clicked.connect(self.load_subscription)
        sub_layout.addWidget(self.btn_load_sub)

        self.btn_clipboard = QPushButton("Из буфера")
        self.btn_clipboard.setProperty("class", "action-btn")
        self.btn_clipboard.clicked.connect(self.load_from_clipboard)
        sub_layout.addWidget(self.btn_clipboard)

        self.btn_ping_all = QPushButton("⚡ Проверить пинг")
        self.btn_ping_all.setProperty("class", "action-btn")
        self.btn_ping_all.clicked.connect(self.start_ping_all)
        sub_layout.addWidget(self.btn_ping_all)

        servers_layout.addLayout(sub_layout)

        # Filter bar
        filter_layout = QHBoxLayout()
        self.filter_input = QLineEdit()
        self.filter_input.setPlaceholderText("Поиск по серверам (страна, протокол, название)...")
        self.filter_input.textChanged.connect(self.filter_servers)
        filter_layout.addWidget(self.filter_input)
        servers_layout.addLayout(filter_layout)

        # Server List Table
        self.server_table = QTableWidget()
        self.server_table.setColumnCount(5)
        self.server_table.setHorizontalHeaderLabels(["#", "Протокол", "Название сервера", "Адрес", "Пинг"])
        self.server_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.server_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.server_table.setEditTriggers(QAbstractItemView.EditTrigger.NoEditTriggers)
        self.server_table.horizontalHeader().setSectionResizeMode(0, QHeaderView.ResizeMode.ResizeToContents)
        self.server_table.horizontalHeader().setSectionResizeMode(1, QHeaderView.ResizeMode.ResizeToContents)
        self.server_table.horizontalHeader().setSectionResizeMode(2, QHeaderView.ResizeMode.Stretch)
        self.server_table.horizontalHeader().setSectionResizeMode(3, QHeaderView.ResizeMode.ResizeToContents)
        self.server_table.horizontalHeader().setSectionResizeMode(4, QHeaderView.ResizeMode.ResizeToContents)
        self.server_table.itemDoubleClicked.connect(self.on_server_double_click)
        self.server_table.itemSelectionChanged.connect(self.on_server_selected)
        servers_layout.addWidget(self.server_table)

        self.tabs.addTab(servers_tab, "Серверы")

        # Tab 2: Logs
        logs_tab = QWidget()
        logs_layout = QVBoxLayout(logs_tab)
        logs_layout.setContentsMargins(12, 12, 12, 12)
        logs_layout.setSpacing(8)

        log_controls = QHBoxLayout()
        clear_logs_btn = QPushButton("Очистить логи")
        clear_logs_btn.setProperty("class", "action-btn")
        clear_logs_btn.clicked.connect(lambda: self.log_viewer.clear())
        log_controls.addWidget(clear_logs_btn)
        log_controls.addStretch()
        logs_layout.addLayout(log_controls)

        self.log_viewer = QTextEdit()
        self.log_viewer.setObjectName("logViewer")
        self.log_viewer.setReadOnly(True)
        logs_layout.addWidget(self.log_viewer)

        self.tabs.addTab(logs_tab, "Логи Sing-Box")

        # Tab 3: Settings
        settings_tab = QWidget()
        settings_layout = QVBoxLayout(settings_tab)
        settings_layout.setContentsMargins(16, 16, 16, 16)
        settings_layout.setSpacing(14)

        dns_lbl = QLabel("Удаленный DNS сервер:")
        dns_lbl.setStyleSheet("font-weight: 600;")
        self.dns_input = QLineEdit("8.8.8.8")
        settings_layout.addWidget(dns_lbl)
        settings_layout.addWidget(self.dns_input)

        port_lbl = QLabel("Локальный Mixed порт (SOCKS5/HTTP):")
        port_lbl.setStyleSheet("font-weight: 600;")
        self.port_input = QLineEdit("2080")
        settings_layout.addWidget(port_lbl)
        settings_layout.addWidget(self.port_input)

        save_settings_btn = QPushButton("Сохранить настройки")
        save_settings_btn.setProperty("class", "action-btn")
        save_settings_btn.clicked.connect(self.save_settings)
        settings_layout.addWidget(save_settings_btn)

        settings_layout.addStretch()
        self.tabs.addTab(settings_tab, "Настройки")

        main_layout.addWidget(self.tabs)

        # Setup System Tray
        self.setup_tray()

    def setup_tray(self):
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(self.style().standardIcon(self.style().StandardPixmap.SP_DriveNetIcon))
        
        tray_menu = QMenu()
        act_show = tray_menu.addAction("Показать окно")
        act_show.triggered.connect(self.show_window)
        
        self.act_tray_toggle = tray_menu.addAction("Подключить")
        self.act_tray_toggle.triggered.connect(self.toggle_connection)
        
        tray_menu.addSeparator()
        act_quit = tray_menu.addAction("Выход")
        act_quit.triggered.connect(self.close_application)
        
        self.tray_icon.setContextMenu(tray_menu)
        self.tray_icon.activated.connect(self.on_tray_activated)
        self.tray_icon.show()

    def on_tray_activated(self, reason):
        if reason == QSystemTrayIcon.ActivationReason.DoubleClick:
            self.show_window()

    def show_window(self):
        self.showNormal()
        self.activateWindow()

    def closeEvent(self, event):
        # Clean disconnect on window close
        if self.is_connected:
            self.runner.stop()
        event.accept()

    def close_application(self):
        if self.is_connected:
            self.runner.stop()
        self.tray_icon.hide()
        sys.exit(0)

    def restart_as_admin(self):
        """Elevates process using PowerShell Start-Process -Verb RunAs"""
        if is_admin():
            return
        script = sys.argv[0]
        params = f'"{script}"'
        try:
            ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, params, None, 1)
            sys.exit(0)
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Не удалось перезапустить от администратора: {e}")

    def on_mode_changed(self):
        self.active_mode = "tun" if self.radio_tun.isChecked() else "proxy"
        if not is_admin() and self.active_mode == "tun":
            self.append_log("[ВНИМАНИЕ] TUN режим требует прав Администратора для создания виртуального Wintun адаптера.")

    def load_subscription(self):
        url = self.sub_input.text().strip()
        if not url:
            QMessageBox.warning(self, "Предупреждение", "Введите ссылку на подписку.")
            return

        self.btn_load_sub.setEnabled(False)
        self.btn_load_sub.setText("Загрузка...")

        def _fetch():
            try:
                nodes, meta = fetch_and_parse_subscription(url)
                self.bridge.subscription_loaded.emit(nodes, meta)
            except Exception as e:
                self.bridge.log_received.emit(f"[ERROR] Ошибка загрузки подписки: {e}")
                self.bridge.subscription_loaded.emit([], {})

        threading.Thread(target=_fetch, daemon=True).start()

    def load_from_clipboard(self):
        clipboard_text = self.sub_input.text().strip()
        from PyQt6.QtWidgets import QApplication
        cb = QApplication.clipboard().text().strip()
        if cb:
            self.sub_input.setText(cb)
            self.load_subscription()

    def on_sub_loaded(self, nodes: List[Dict[str, Any]], meta: Dict[str, str]):
        self.btn_load_sub.setEnabled(True)
        self.btn_load_sub.setText("Обновить подписку")
        
        if not nodes:
            QMessageBox.warning(self, "Информация", "Не удалось найти подходящих серверов в подписке.")
            return

        self.nodes = nodes
        self.render_server_table()
        self.save_settings()
        self.append_log(f"[INFO] Успешно загружено серверов: {len(nodes)}")
        
        # Automatically ping all servers
        self.start_ping_all()

    def render_server_table(self):
        self.server_table.setRowCount(len(self.nodes))
        filter_text = self.filter_input.text().lower()

        for idx, node in enumerate(self.nodes):
            name = node.get("name", f"Server {idx+1}")
            proto = node.get("protocol", "UNKNOWN")
            addr = f"{node.get('address')}:{node.get('port')}"
            
            # Match filter
            matches = (filter_text in name.lower()) or (filter_text in proto.lower()) or (filter_text in addr.lower())
            self.server_table.setRowHidden(idx, not matches)

            # Item 0: Index
            item_idx = QTableWidgetItem(str(idx + 1))
            item_idx.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            self.server_table.setItem(idx, 0, item_idx)

            # Item 1: Protocol Badge
            item_proto = QTableWidgetItem(f" {proto} ")
            item_proto.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if "REALITY" in proto:
                item_proto.setForeground(QColor("#00d2ff"))
            elif "WIREGUARD" in proto:
                item_proto.setForeground(QColor("#a855f7"))
            elif "AMNEZIA" in proto:
                item_proto.setForeground(QColor("#f97316"))
            elif "TROJAN" in proto:
                item_proto.setForeground(QColor("#10b981"))
            elif "SHADOWSOCKS" in proto:
                item_proto.setForeground(QColor("#facc15"))
            self.server_table.setItem(idx, 1, item_proto)

            # Item 2: Name
            item_name = QTableWidgetItem(name)
            item_name.setFont(QFont("Segoe UI", 10, QFont.Weight.DemiBold))
            self.server_table.setItem(idx, 2, item_name)

            # Item 3: Address
            item_addr = QTableWidgetItem(addr)
            item_addr.setForeground(QColor("#94a3b8"))
            self.server_table.setItem(idx, 3, item_addr)

            # Item 4: Ping
            ping_val = node.get("ping", None)
            ping_str = f"{ping_val} ms" if ping_val and ping_val > 0 else "—"
            item_ping = QTableWidgetItem(ping_str)
            item_ping.setTextAlignment(Qt.AlignmentFlag.AlignCenter)
            if ping_val and ping_val > 0:
                if ping_val < 120:
                    item_ping.setForeground(QColor("#10b981"))
                elif ping_val < 250:
                    item_ping.setForeground(QColor("#facc15"))
                else:
                    item_ping.setForeground(QColor("#ef4444"))
            self.server_table.setItem(idx, 4, item_ping)

        # Restore selection if possible
        if 0 <= self.selected_node_idx < len(self.nodes):
            self.server_table.selectRow(self.selected_node_idx)

    def filter_servers(self):
        filter_text = self.filter_input.text().lower()
        for idx, node in enumerate(self.nodes):
            name = node.get("name", "").lower()
            proto = node.get("protocol", "").lower()
            addr = f"{node.get('address')}:{node.get('port')}".lower()
            matches = (filter_text in name) or (filter_text in proto) or (filter_text in addr)
            self.server_table.setRowHidden(idx, not matches)

    def on_server_selected(self):
        selected = self.server_table.selectedItems()
        if selected:
            row = selected[0].row()
            self.selected_node_idx = row

    def on_server_double_click(self, item):
        row = item.row()
        self.selected_node_idx = row
        self.start_connection()

    def start_ping_all(self):
        if not self.nodes:
            return
        self.btn_ping_all.setEnabled(False)
        self.btn_ping_all.setText("Проверка...")

        def _ping_worker():
            test_all_nodes(
                self.nodes,
                callback=lambda idx, lat: self.bridge.ping_updated.emit(idx, lat)
            )
            QTimer.singleShot(0, lambda: self.btn_ping_all.setEnabled(True))
            QTimer.singleShot(0, lambda: self.btn_ping_all.setText("⚡ Проверить пинг"))

        threading.Thread(target=_ping_worker, daemon=True).start()

    def on_ping_result(self, idx: int, lat: int):
        if 0 <= idx < len(self.nodes):
            self.nodes[idx]["ping"] = lat
            item_ping = self.server_table.item(idx, 4)
            if item_ping:
                ping_str = f"{lat} ms" if lat > 0 else "Таймаут"
                item_ping.setText(ping_str)
                if lat > 0:
                    if lat < 120:
                        item_ping.setForeground(QColor("#10b981"))
                    elif lat < 250:
                        item_ping.setForeground(QColor("#facc15"))
                    else:
                        item_ping.setForeground(QColor("#ef4444"))
                else:
                    item_ping.setForeground(QColor("#64748b"))

    def toggle_connection(self):
        if self.is_connected:
            self.stop_connection()
        else:
            self.start_connection()

    def start_connection(self):
        if not self.nodes:
            QMessageBox.warning(self, "Ошибка", "Список серверов пуст. Добавьте подписку.")
            return

        if self.selected_node_idx < 0 or self.selected_node_idx >= len(self.nodes):
            self.selected_node_idx = 0
            self.server_table.selectRow(0)

        node = self.nodes[self.selected_node_idx]
        mode = self.active_mode

        if mode == "tun" and not is_admin():
            reply = QMessageBox.question(
                self,
                "Права Администратора",
                "TUN-режим требует прав администратора для создания виртуального Wintun интерфейса.\n"
                "Вы хотите переключиться в режим System Proxy или продолжить?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if reply == QMessageBox.StandardButton.Yes:
                self.radio_proxy.setChecked(True)
                mode = "proxy"

        try:
            port = int(self.port_input.text().strip() or "2080")
        except ValueError:
            port = 2080

        dns = self.dns_input.text().strip() or "8.8.8.8"

        cfg = generate_singbox_config(node, mode=mode, mixed_port=port, dns_server=dns)
        
        self.append_log(f"[INFO] Подключение к: {node.get('name')} ({node.get('protocol')}) в режиме {mode.upper()}...")
        success = self.runner.start(cfg, mode=mode)
        if success:
            self.is_connected = True
            self.update_ui_state(connected=True, node_name=node.get('name'))
        else:
            QMessageBox.critical(self, "Ошибка", "Не удалось запустить sing-box. Проверьте вкладку логов.")

    def stop_connection(self):
        self.runner.stop()
        self.is_connected = False
        self.update_ui_state(connected=False)

    def on_runner_status(self, st: str):
        if st == "disconnected" and self.is_connected:
            self.is_connected = False
            self.update_ui_state(connected=False)

    def update_ui_state(self, connected: bool, node_name: str = ""):
        self.connect_btn.setProperty("connected", "true" if connected else "false")
        self.connect_btn.style().unpolish(self.connect_btn)
        self.connect_btn.style().polish(self.connect_btn)

        if connected:
            self.connect_btn.setText("ОТКЛЮЧИТЬ")
            self.status_lbl.setText(f"●  Подключено: {node_name}")
            self.status_lbl.setStyleSheet("color: #10b981; font-weight: 700;")
            self.act_tray_toggle.setText("Отключить")
            self.tray_icon.setToolTip(f"Sing-Box: Подключено к {node_name}")
        else:
            self.connect_btn.setText("ПОДКЛЮЧИТЬ")
            self.status_lbl.setText("●  Отключено")
            self.status_lbl.setStyleSheet("color: #94a3b8; font-weight: 600;")
            self.act_tray_toggle.setText("Подключить")
            self.tray_icon.setToolTip("Sing-Box: Отключено")

    def append_log(self, text: str):
        self.log_viewer.append(text)

    def save_settings(self):
        data = {
            "sub_url": self.sub_input.text(),
            "dns": self.dns_input.text(),
            "port": self.port_input.text(),
            "mode": self.active_mode,
            "selected_idx": self.selected_node_idx,
            "nodes": self.nodes
        }
        try:
            with open(self.settings_file, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            self.append_log("[INFO] Настройки сохранены")
        except Exception as e:
            self.append_log(f"[WARN] Ошибка сохранения настроек: {e}")

    def load_settings(self):
        if not self.settings_file.exists():
            return
        try:
            with open(self.settings_file, "r", encoding="utf-8") as f:
                data = json.load(f)
            self.sub_input.setText(data.get("sub_url", ""))
            self.dns_input.setText(data.get("dns", "8.8.8.8"))
            self.port_input.setText(data.get("port", "2080"))
            saved_mode = data.get("mode", "tun")
            if saved_mode == "proxy":
                self.radio_proxy.setChecked(True)
            else:
                self.radio_tun.setChecked(True)
            self.nodes = data.get("nodes", [])
            self.selected_node_idx = data.get("selected_idx", -1)
            if self.nodes:
                self.render_server_table()
        except Exception as e:
            self.append_log(f"[WARN] Ошибка загрузки настроек: {e}")
