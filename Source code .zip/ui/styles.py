MODERN_STYLE = """
/* Base Application Style */
QWidget {
    background-color: #0f121a;
    color: #e2e8f0;
    font-family: "Segoe UI", "Inter", sans-serif;
    font-size: 13px;
    selection-background-color: #3b82f6;
    selection-color: #ffffff;
}

/* Card Containers */
QFrame.card {
    background-color: #171d2b;
    border: 1px solid #232c3f;
    border-radius: 12px;
    padding: 14px;
}

QFrame.header-card {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #1a233a, stop:1 #131826);
    border: 1px solid #28354f;
    border-radius: 12px;
    padding: 16px;
}

/* Big Connect Button */
QPushButton#connectBtn {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00b4d8, stop:1 #0077b6);
    color: #ffffff;
    font-size: 16px;
    font-weight: 700;
    border: none;
    border-radius: 25px;
    padding: 14px 28px;
    letter-spacing: 1px;
}

QPushButton#connectBtn:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #00c6ff, stop:1 #0096c7);
}

QPushButton#connectBtn:pressed {
    background: #023e8a;
}

QPushButton#connectBtn[connected="true"] {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #e63946, stop:1 #d90429);
}

QPushButton#connectBtn[connected="true"]:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #ff4d6d, stop:1 #ef233c);
}

/* Secondary Buttons */
QPushButton.action-btn {
    background-color: #222b3e;
    color: #f1f5f9;
    border: 1px solid #334155;
    border-radius: 8px;
    padding: 8px 16px;
    font-weight: 600;
}

QPushButton.action-btn:hover {
    background-color: #2d3952;
    border-color: #00b4d8;
    color: #ffffff;
}

QPushButton.action-btn:pressed {
    background-color: #182030;
}

/* Input Fields */
QLineEdit {
    background-color: #131824;
    border: 1px solid #2d3748;
    border-radius: 8px;
    padding: 8px 12px;
    color: #f8fafc;
    font-size: 13px;
}

QLineEdit:focus {
    border: 1px solid #00b4d8;
    background-color: #171d2b;
}

/* Radio buttons / Mode selector */
QRadioButton {
    color: #cbd5e1;
    font-size: 13px;
    font-weight: 500;
    spacing: 8px;
}

QRadioButton::indicator {
    width: 18px;
    height: 18px;
    border-radius: 9px;
    border: 2px solid #475569;
    background-color: #131824;
}

QRadioButton::indicator:hover {
    border-color: #00b4d8;
}

QRadioButton::indicator:checked {
    background-color: #00b4d8;
    border: 3px solid #0f121a;
}

/* Table / Server List */
QTableWidget {
    background-color: #131824;
    border: 1px solid #232c3f;
    border-radius: 10px;
    gridline-color: transparent;
    selection-background-color: #1e293b;
    selection-color: #ffffff;
}

QTableWidget::item {
    padding: 10px 8px;
    border-bottom: 1px solid #1a2233;
}

QTableWidget::item:selected {
    background-color: #1e293b;
    border-left: 3px solid #00b4d8;
}

QHeaderView::section {
    background-color: #171d2b;
    color: #94a3b8;
    font-weight: 600;
    font-size: 12px;
    padding: 8px;
    border: none;
    border-bottom: 2px solid #232c3f;
}

/* Scrollbars */
QScrollBar:vertical {
    border: none;
    background: #0f121a;
    width: 8px;
    margin: 0px;
}

QScrollBar::handle:vertical {
    background: #334155;
    min-height: 25px;
    border-radius: 4px;
}

QScrollBar::handle:vertical:hover {
    background: #475569;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0px;
}

/* Tab Widget */
QTabWidget::pane {
    border: 1px solid #232c3f;
    border-radius: 8px;
    background-color: #131824;
    top: -1px;
}

QTabBar::tab {
    background-color: #171d2b;
    color: #94a3b8;
    padding: 8px 18px;
    border-top-left-radius: 8px;
    border-top-right-radius: 8px;
    font-weight: 600;
    margin-right: 4px;
}

QTabBar::tab:selected {
    background-color: #131824;
    color: #00b4d8;
    border: 1px solid #232c3f;
    border-bottom: none;
}

/* Text Edit (Logs) */
QTextEdit#logViewer {
    background-color: #0b0d13;
    color: #a7f3d0;
    font-family: "Consolas", "Courier New", monospace;
    font-size: 12px;
    border: 1px solid #1e293b;
    border-radius: 8px;
    padding: 10px;
}
"""
