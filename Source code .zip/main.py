import sys
import os
import ctypes
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
sys.path.insert(0, str(BASE_DIR))

from PyQt6.QtWidgets import QApplication
from PyQt6.QtCore import Qt
from ui.main_window import MainWindow

def setup_windows_env():
    # Set Windows App User Model ID for proper taskbar grouping
    try:
        app_id = "myvpn.singbox.client.1.0"
        ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(app_id)
    except Exception:
        pass

def main():
    setup_windows_env()
    
    app = QApplication(sys.argv)
    app.setApplicationName("Sing-Box VPN Client")
    app.setOrganizationName("CustomVPN")

    window = MainWindow()
    window.show()

    sys.exit(app.exec())

if __name__ == "__main__":
    main()
